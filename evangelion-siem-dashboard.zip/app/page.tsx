'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Activity, AlertTriangle, ArrowUpRight, Bell, BookOpen, ChevronRight, CircleDot, Crosshair, Database, Gauge, Globe2, LockKeyhole, Menu, Radar, Search, Settings2, ShieldCheck, Terminal, Wrench, X } from 'lucide-react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Sphere } from '@react-three/drei'
import * as THREE from 'three'

const news = [
  ['09:30:11', 'RANSOMWARE', 'LockBit 3.0 targets Healthcare sector', 'BISA_FEED'],
  ['09:28:42', 'PHISHING', 'Credential harvest detected via OAuth lure', 'NERV_SOC'],
  ['09:25:08', 'MALWARE', 'FrostyGoop OT campaign attributed to Unit 42', 'MAGI_FEED'],
  ['09:21:33', 'EXPLOIT', 'CVE-2025-44228 exploitation observed in EU', 'BISA_FEED'],
  ['09:18:09', 'BOTNET', 'Mirai variant scanning edge infrastructure', 'NERV_SOC'],
]

const bars = [24, 37, 28, 48, 35, 62, 44, 78, 52, 68, 84, 57, 92, 66, 75, 88, 61, 96, 72, 84, 58, 69, 82, 93]
const vectors = [['MALWARE', '42.8K', 'HIGH'], ['RANSOMWARE', '18.4K', 'CRITICAL'], ['PHISHING', '12.7K', 'MEDIUM'], ['EXPLOIT', '8.9K', 'HIGH']]

function Panel({ title, tag, children, className = '' }: { title: string; tag?: string; children: React.ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-head"><div className="panel-title"><span className="panel-mark" />{title}</div>{tag && <span className="panel-tag">[{tag}]</span>}</div>{children}</section>
}

const attackRoutes = [
  { origin: [35, 105], target: [39, -98], color: '#ff4d4d', label: 'CN → US' },
  { origin: [55, 40], target: [52, 13], color: '#ff9d3d', label: 'RU → DE' },
  { origin: [-10, -52], target: [51, -1], color: '#46b9ff', label: 'BR → UK' },
]

function geoPoint(lat: number, lon: number, radius = 2.03) {
  const phi = (90 - lat) * Math.PI / 180
  const theta = (lon + 180) * Math.PI / 180
  return new THREE.Vector3(-radius * Math.sin(phi) * Math.cos(theta), radius * Math.cos(phi), radius * Math.sin(phi) * Math.sin(theta))
}

function AttackArc({ route, active }: { route: typeof attackRoutes[number]; active: boolean }) {
  const projectile = useRef<THREE.Mesh>(null)
  const origin = geoPoint(route.origin[0], route.origin[1])
  const target = geoPoint(route.target[0], route.target[1])
  const points = useMemo(() => {
    const curve = new THREE.QuadraticBezierCurve3(origin, origin.clone().add(target).normalize().multiplyScalar(2.72), target)
    return curve.getPoints(32)
  }, [origin, target])
  useFrame(({ clock }) => {
    if (!projectile.current) return
    const progress = active ? (clock.getElapsedTime() % 3.2) / 3.2 : 1
    const index = Math.min(points.length - 1, Math.floor(progress * (points.length - 1)))
    projectile.current.position.copy(points[index])
    projectile.current.visible = active
  })
  return <><line><bufferGeometry attach="geometry" onUpdate={(geometry) => geometry.setFromPoints(points)} /><lineBasicMaterial color={route.color} transparent opacity={active ? 0.9 : 0.18} /></line><mesh ref={projectile}><sphereGeometry args={[0.06, 12, 12]} /><meshBasicMaterial color={route.color} /></mesh><mesh position={target}><ringGeometry args={[0.09, 0.15, 32]} /><meshBasicMaterial color={route.color} transparent opacity={active ? 0.9 : 0.25} side={THREE.DoubleSide} /></mesh></>
}

function Globe() {
  const [attack, setAttack] = useState(0)
  useEffect(() => { const id = setInterval(() => setAttack((value) => value + 1), 3200); return () => clearInterval(id) }, [])
  const activeRoute = attackRoutes[attack % attackRoutes.length]
  return <div className="globe-wrap" aria-label="Interactive 3D Earth threat map. Drag to rotate.">
    <Canvas camera={{ position: [0, 0.2, 6.1], fov: 38 }} dpr={[1, 2]}>
      <ambientLight intensity={1.4} />
      <pointLight position={[4, 3, 5]} intensity={3} color="#bde8ff" />
      <Earth />
      {attackRoutes.map((route) => <AttackArc key={route.label} route={route} active={route.label === activeRoute.label} />)}
      <OrbitControls enablePan={false} minDistance={4.3} maxDistance={7} rotateSpeed={0.7} autoRotate autoRotateSpeed={0.35} />
    </Canvas>
    <span className="map-label label-a">[ACTIVE] {activeRoute.label} <b>LIVE</b></span>
    <div className="globe-caption"><Globe2 /> THREAT SURFACE // LIVE TELEMETRY <b>DRAG TO ROTATE // ATTACK PULSE {String(attack + 1).padStart(2, '0')}</b></div>
  </div>
}

function Earth() {
  return <>
    <Sphere args={[2, 64, 64]}><meshStandardMaterial color="#123344" roughness={0.72} metalness={0.18} emissive="#062433" emissiveIntensity={0.45} wireframe /></Sphere>
    <Sphere args={[1.94, 48, 48]}><meshStandardMaterial color="#0a1b26" roughness={0.9} emissive="#031019" emissiveIntensity={0.35} /></Sphere>
  </>
}

export default function Page() {
  const [query, setQuery] = useState('')
  const [pulse, setPulse] = useState(0)
  const [menuOpen, setMenuOpen] = useState(false)
  const [toast, setToast] = useState('')
  useEffect(() => { const id = setInterval(() => setPulse((p) => p + 1), 4000); return () => clearInterval(id) }, [])
  const liveNews = useMemo(() => news.map((item, i) => i === pulse % news.length ? [...item.slice(0, 3), 'LIVE_SYNC'] : item), [pulse])
  const launch = (name: string) => { setToast(`${name} // REQUEST QUEUED`); setTimeout(() => setToast(''), 2400) }

  return <main className="command-center">
    <header className="topbar"><div className="brand"><div className="brand-symbol">N</div><div><div className="brand-name">NERV<span>///</span>NET</div><div className="brand-sub">TACTICAL INTELLIGENCE SYSTEM</div></div></div><div className="header-status"><span className="status-dot" />MAGI_STATUS: <b>CONNECTED</b><span className="divider" />DEPLOY_CODE: <b className="orange">NERV-01</b></div><button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu"><Menu /></button><div className={`user-chip ${menuOpen ? 'open' : ''}`}><div className="avatar">EO</div><div><strong>EVA_OPERATOR_01</strong><small>CLEARANCE: MAGI</small></div><ChevronRight /></div></header>
    <div className="command-row"><div className="command-input"><Search /><input aria-label="Command or search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ENTER_COMMAND_OR_SEARCH..." /><kbd>⌘ K</kbd></div><div className="system-time"><span className="status-dot green" />SYSTEM_TIME <b>09:31:44 UTC</b></div></div>
    {query && <div className="search-result">SEARCHING ALL TELEMETRY FOR: <b>{query.toUpperCase()}</b><X onClick={() => setQuery('')} /></div>}

    <div className="dashboard-grid">
      <Panel title="EARTH // GLOBAL VIEW" tag="THREAT_SURFACE" className="earth-panel"><div className="panel-corner">LIVE</div><Globe /><div className="legend"><span><i className="dot red" />CRITICAL</span><span><i className="dot orange" />ELEVATED</span><span><i className="dot blue" />OBSERVED</span></div></Panel>
      <Panel title="DASHBOARD OF CURRENT ATTACKS" tag="SIEM_CORE" className="metrics-panel"><div className="kpi-grid"><div className="kpi critical"><span>ACTIVE_THREATS</span><strong>1,248</strong><em>+12.4%</em><div className="kpi-bar"><i /></div></div><div className="kpi secure"><span>BLOCKED_EVENTS_24H</span><strong>84,392</strong><em>+8.1%</em><div className="kpi-bar"><i /></div></div><div className="kpi warning"><span>ACTIVE_CVE_ALERTS</span><strong>73</strong><em>+03.2%</em><div className="kpi-bar"><i /></div></div></div><div className="chart-head"><span>THREAT TIMELINE <small>// LAST 60 MIN</small></span><span className="chart-value"><i /> EVENTS / MIN</span></div><div className="bar-chart">{bars.map((h, i) => <div className={`bar ${i % 5 === 0 ? 'hot' : ''}`} style={{ height: `${h}%` }} key={i}><span /></div>)}</div><div className="chart-axis"><span>-60M</span><span>-45M</span><span>-30M</span><span>-15M</span><span>NOW</span></div><div className="vector-table"><div className="table-label">ATTACK VECTOR <span>FREQUENCY</span><span>SEVERITY</span></div>{vectors.map(([type, count, severity]) => <div className="vector-row" key={type}><b>[{type}]</b><span>{count}</span><em className={severity.toLowerCase()}>{severity}</em></div>)}</div></Panel>
      <Panel title="TOP NEWS: CURRENT ATTACKS" tag="OSINT_FEED" className="news-panel"><div className="feed-head"><span>[TIMESTAMP]</span><span>[THREAT_TYPE]</span><span>[SOURCE / STATUS]</span></div><div className="feed-list">{liveNews.map(([time, type, source, status]) => <div className="feed-row" key={time}><time>{time}</time><b className={type === 'RANSOMWARE' ? 'red-text' : ''}>{type}</b><div><span>{source}</span><small>{status} <i className="status-dot green" /></small></div></div>)}</div><div className="feed-footer"><span className="status-dot green" />STREAMING // {news.length} SOURCES ACTIVE <ArrowUpRight /></div></Panel>
      <Panel title="OTHER TOOLS & INFORMED USER" tag="UTILITY_DECK" className="tools-panel"><div className="tool-list">{[['LAUNCH_CVE_SEARCH', Search], ['ACCESS_THREAT_LIBRARY', BookOpen], ['RUN_SYSTEM_DIAG', Gauge], ['VIEW_BEST_PRACTICES', ShieldCheck]].map(([name, Icon]) => <button key={name as string} onClick={() => launch(name as string)}><Icon /><span>{name as string}</span><ChevronRight /></button>)}</div><div className="utility-status"><Terminal /> ALL SYSTEMS NOMINAL <span>99.98% UPTIME</span></div></Panel>
      <Panel title="USER ACCOMPLISHMENTS" tag="OPERATOR_PROFILE" className="profile-panel"><div className="profile-main"><div className="profile-avatar"><Crosshair /></div><div><strong>EVA_OPERATOR_01</strong><span>SECURITY OPERATIONS SPECIALIST</span></div><div className="level">LVL <b>07</b></div></div><div className="profile-stats"><div><span>MISSIONS_COMPLETED</span><b>124</b></div><div><span>RECENT_RESOLUTIONS</span><b>14</b></div><div><span>SKILL_RATING</span><b>87.4</b></div></div><div className="progress-line"><span>OPERATOR SYNC</span><i><b /></i><strong>87%</strong></div></Panel>
    </div>
    <footer><span><Activity /> NERV NET // COMMAND CENTER V2.7.4</span><span><LockKeyhole /> ENCRYPTED CONNECTION</span><span><Database /> DATA RETENTION: 90 DAYS</span><span><Settings2 /> CONFIG</span></footer>
    {toast && <div className="toast"><CircleDot />{toast}</div>}
  </main>
}
